package uz.urinboydev.domproduct.app.models

data class Language(
    val code: String,
    val name: String,
    val flag: String
)