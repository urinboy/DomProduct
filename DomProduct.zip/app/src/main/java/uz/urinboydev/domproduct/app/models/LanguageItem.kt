package uz.urinboydev.domproduct.app.models

data class LanguageItem(
    val code: String,
    val name: String,
    val flag: String
)