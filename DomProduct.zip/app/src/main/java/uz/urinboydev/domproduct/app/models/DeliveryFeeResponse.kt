package uz.urinboydev.domproduct.app.models

data class DeliveryFeeResponse(
    val city_id: Int,
    val delivery_fee: Double
)