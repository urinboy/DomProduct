package uz.urinboydev.domproduct.app.models

data class UpdateCartRequest(
    val quantity: Int
)